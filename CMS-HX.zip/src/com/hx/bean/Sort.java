package com.hx.bean;

public class Sort {
	private int id;
	private String sortName;
	private int sortLevel;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSortName() {
		return sortName;
	}
	public void setSortName(String sortName) {
		this.sortName = sortName;
	}
	public int getSortLevel() {
		return sortLevel;
	}
	public void setSortLevel(int sortLevel) {
		this.sortLevel = sortLevel;
	}
	
	
	
	
	

}
