package com.hx.utils;

public class StringUtils {

	public static boolean isEmpty(String action) {
		return action==null||action.length()==0;
	}
	
}
