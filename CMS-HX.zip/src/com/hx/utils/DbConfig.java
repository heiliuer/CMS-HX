package com.hx.utils;

public class DbConfig {
	public static final String url = "jdbc:mysql://localhost:3306/hx-cms??useUnicode=true&characterEncoding=utf8";
	public static final String user = "root";
	public static final String password = "123456";

}
